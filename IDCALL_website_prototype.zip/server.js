const express = require("express");
const http = require("http");
const { Server } = require("socket.io");
const crypto = require("crypto");

const app = express();
const server = http.createServer(app);
const io = new Server(server);
app.use(express.static("public"));

const users = new Map();       // Prototype only: resets when server restarts
const online = new Map();      // userId -> socketId
const messages = new Map();    // recipientId -> one-time message objects

function currentPassword() {
  // India time (IST), HH:MM. Deliberately matches the requested prototype behavior.
  return new Intl.DateTimeFormat("en-GB", {
    timeZone: "Asia/Kolkata", hour: "2-digit", minute: "2-digit", hour12: false
  }).format(new Date());
}
function makeId() {
  return "ID-" + crypto.randomBytes(3).toString("hex").toUpperCase();
}

io.on("connection", socket => {
  socket.emit("clock-password", currentPassword());
  const clock = setInterval(() => socket.emit("clock-password", currentPassword()), 1000);

  socket.on("register", ({ username }, callback) => {
    username = String(username || "").trim().slice(0, 24);
    if (!username) return callback({ ok: false, error: "Enter a username." });
    if ([...users.values()].some(u => u.username.toLowerCase() === username.toLowerCase()))
      return callback({ ok: false, error: "Username already exists. Try another." });
    const userId = makeId();
    users.set(userId, { username, userId });
    callback({ ok: true, userId, username });
  });

  socket.on("login", ({ userId, password }, callback) => {
    const user = users.get(String(userId || "").trim().toUpperCase());
    if (!user) return callback({ ok: false, error: "User ID not found. Register first on this running demo." });
    if (String(password) !== currentPassword())
      return callback({ ok: false, error: "Password must match current India time (HH:MM). Try again." });
    online.set(user.userId, socket.id);
    socket.data.userId = user.userId;
    callback({ ok: true, user });
    io.emit("presence", [...online.keys()]);
    const pending = messages.get(user.userId) || [];
    socket.emit("pending-messages", pending.map(m => ({ messageId: m.messageId, from: m.from })));
  });

  socket.on("call-user", ({ targetId }) => {
    const targetSocket = online.get(String(targetId || "").toUpperCase());
    if (!socket.data.userId) return;
    if (!targetSocket) return socket.emit("call-error", "User is offline.");
    io.to(targetSocket).emit("incoming-call", { from: socket.data.userId });
  });
  socket.on("call-accept", ({ to }) => {
    const targetSocket = online.get(String(to || "").toUpperCase());
    if (targetSocket) io.to(targetSocket).emit("call-accepted", { from: socket.data.userId });
  });
  socket.on("call-reject", ({ to }) => {
    const targetSocket = online.get(String(to || "").toUpperCase());
    if (targetSocket) io.to(targetSocket).emit("call-rejected", { from: socket.data.userId });
  });
  // WebRTC signaling messages: offer, answer, ICE candidates
  for (const event of ["webrtc-offer", "webrtc-answer", "webrtc-ice"]) {
    socket.on(event, ({ to, data }) => {
      const targetSocket = online.get(String(to || "").toUpperCase());
      if (targetSocket) io.to(targetSocket).emit(event, { from: socket.data.userId, data });
    });
  }
  socket.on("hangup", ({ to }) => {
    const targetSocket = online.get(String(to || "").toUpperCase());
    if (targetSocket) io.to(targetSocket).emit("hangup", { from: socket.data.userId });
  });

  socket.on("send-once-message", ({ to, body }, callback) => {
    if (!socket.data.userId) return callback?.({ ok: false, error: "Login first." });
    const recipient = String(to || "").toUpperCase();
    if (!users.has(recipient)) return callback?.({ ok: false, error: "User ID not found." });
    body = String(body || "").slice(0, 500);
    if (!body) return callback?.({ ok: false, error: "Message is empty." });
    const msg = { messageId: crypto.randomUUID(), from: socket.data.userId, body };
    const inbox = messages.get(recipient) || [];
    inbox.push(msg);
    messages.set(recipient, inbox);
    const targetSocket = online.get(recipient);
    if (targetSocket) io.to(targetSocket).emit("pending-messages", [{ messageId: msg.messageId, from: msg.from }]);
    callback?.({ ok: true });
  });
  socket.on("view-once-message", ({ messageId }, callback) => {
    const userId = socket.data.userId;
    if (!userId) return callback?.({ ok: false, error: "Login first." });
    const inbox = messages.get(userId) || [];
    const index = inbox.findIndex(m => m.messageId === messageId);
    if (index < 0) return callback?.({ ok: false, error: "Message was already viewed or is unavailable." });
    const [msg] = inbox.splice(index, 1); // delete before returning body
    messages.set(userId, inbox);
    callback?.({ ok: true, from: msg.from, body: msg.body });
  });

  socket.on("disconnect", () => {
    clearInterval(clock);
    const id = socket.data.userId;
    if (id && online.get(id) === socket.id) online.delete(id);
    io.emit("presence", [...online.keys()]);
  });
});

const PORT = process.env.PORT || 3000;
server.listen(PORT, () => console.log(`IDCALL running at http://localhost:${PORT}`));
