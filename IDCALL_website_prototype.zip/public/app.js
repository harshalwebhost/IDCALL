const socket = io();
const $ = id => document.getElementById(id);
let me = null, peer = null, pc = null, localStream = null;
const seenNotice = new Set();

socket.on("clock-password", t => { $("clock").textContent = "Live password: " + t; $("password").value = t; });
$("register").onclick = () => socket.emit("register", {username:$("newName").value}, result => {
  if (!result.ok) return $("status").textContent = result.error;
  $("created").textContent = `Account created: ${result.username} • Your ID: ${result.userId}`;
  $("loginId").value = result.userId;
});
$("login").onclick = () => socket.emit("login", {userId:$("loginId").value, password:$("password").value}, result => {
  if (!result.ok) return $("status").textContent = result.error;
  me = result.user; $("dashboard").classList.remove("hidden"); $("account").classList.add("hidden");
  $("welcome").textContent = "Welcome, " + me.username; $("myId").textContent = me.userId;
  $("status").textContent = "";
});
socket.on("presence", ids => $("online").textContent = ids.join(", ") || "Nobody");

$("call").onclick = async () => {
  if (!me) return;
  peer = $("callTarget").value.trim().toUpperCase();
  if (!peer) return $("callStatus").textContent = "Enter a user ID.";
  try {
    localStream = await navigator.mediaDevices.getUserMedia({audio:true, video:false});
    pc = createPeer();
    socket.emit("call-user", {targetId:peer});
    $("callStatus").textContent = "Calling " + peer + "…";
  } catch(e) { $("callStatus").textContent = "Microphone access failed: " + e.message; }
};
function createPeer() {
  const connection = new RTCPeerConnection({iceServers:[{urls:"stun:stun.l.google.com:19302"}]});
  localStream?.getTracks().forEach(track => connection.addTrack(track, localStream));
  connection.onicecandidate = e => { if(e.candidate) socket.emit("webrtc-ice",{to:peer,data:e.candidate}); };
  connection.ontrack = e => {
    let audio = $("remoteAudio"); if(!audio){audio=document.createElement("audio");audio.id="remoteAudio";audio.autoplay=true;document.body.appendChild(audio);}
    audio.srcObject=e.streams[0];
  };
  return connection;
}
socket.on("incoming-call", async ({from}) => {
  if (!confirm("Incoming voice call from " + from + ". Accept?")) { socket.emit("call-reject",{to:from}); return; }
  peer=from;
  try {
    localStream=await navigator.mediaDevices.getUserMedia({audio:true,video:false});
    pc=createPeer(); socket.emit("call-accept",{to:from});
    $("callStatus").textContent="Connected with " + from + " (setting up audio)…";
  } catch(e){ $("callStatus").textContent="Microphone access failed: "+e.message; }
});
socket.on("call-accepted", async ({from}) => {
  if(!pc || from!==peer) return;
  const offer=await pc.createOffer(); await pc.setLocalDescription(offer);
  socket.emit("webrtc-offer",{to:peer,data:offer}); $("callStatus").textContent="Voice call connecting…";
});
socket.on("webrtc-offer", async ({from,data}) => {
  if(!pc || from!==peer) return;
  await pc.setRemoteDescription(data); const answer=await pc.createAnswer(); await pc.setLocalDescription(answer);
  socket.emit("webrtc-answer",{to:peer,data:answer});
});
socket.on("webrtc-answer", async ({from,data}) => { if(pc && from===peer) await pc.setRemoteDescription(data); $("callStatus").textContent="Voice call connected."; });
socket.on("webrtc-ice", async ({from,data}) => { if(pc && from===peer) try{await pc.addIceCandidate(data)}catch(e){} });
socket.on("call-rejected", ({from}) => $("callStatus").textContent="Call rejected by "+from);
socket.on("call-error", msg => $("callStatus").textContent=msg);
socket.on("hangup", () => endCall(false));
$("hangup").onclick=()=>{if(peer)socket.emit("hangup",{to:peer});endCall(true)};
function endCall(send){pc?.close();pc=null;localStream?.getTracks().forEach(t=>t.stop());localStream=null;peer=null;$("callStatus").textContent="Call ended.";const audio=$("remoteAudio");if(audio)audio.remove();}

$("send").onclick=()=>socket.emit("send-once-message",{to:$("msgTarget").value,body:$("msgBody").value},r=>{
  $("status").textContent=r.ok?"Message sent. It can be opened once.":r.error;if(r.ok)$("msgBody").value="";
});
socket.on("pending-messages", items => items.forEach(item => {
  if(seenNotice.has(item.messageId)) return; seenNotice.add(item.messageId);
  const box=document.createElement("div");box.className="msg";
  const button=document.createElement("button");button.textContent="New one-time message from "+item.from+" — Tap to view";
  button.onclick=()=>socket.emit("view-once-message",{messageId:item.messageId},r=>{
    if(!r.ok){box.textContent=r.error;return;}
    box.textContent="From "+r.from+": "+r.body+" (viewed; message removed)";
  });
  box.appendChild(button);$("inbox").prepend(box);
}));
